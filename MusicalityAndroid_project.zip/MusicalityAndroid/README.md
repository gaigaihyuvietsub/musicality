# Musicality Android prototype

This is an Android app source project using Python + Kivy. It includes an initial case-sensitive parser for the Musicality notation discussed so far.

## What works in this prototype
- Android-friendly UI with a text field and analyze button.
- `Sol(5,x5:y4` parsed as Sol, row 5, x=5, y=4.
- Recognizes note-value tokens `D`, `R`, `M`, `F`, `S`, `L`, `S'`, `D¹`.
- Keeps `Sol(` and `sol` distinct.
- Does not invent meanings for `#` and `~`.

## Important limitation
This prototype does not yet generate or play sound, and is not itself an APK. Musicality's language rules still need to be defined further.

## Build APK in the cloud
A GitHub Actions workflow is included at `.github/workflows/build-apk.yml`.
1. Create a repository on GitHub and upload the contents of this folder (phone browser can use GitHub's upload files feature).
2. Open the repository's **Actions** tab and select **Build Musicality APK**.
3. Press **Run workflow**. On success, open the workflow run and download the **Musicality-debug-apk** artifact.
4. Download and extract the artifact on your Android phone, then install the APK. Android may ask you to allow installs from that browser/files app.

A debug APK is for testing, not Play Store publishing.
